package fr.fifoube.packets;

import fr.fifoube.blocks.tileentity.TileEntityBlockChanger;
import java.util.function.Supplier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.network.NetworkEvent;

public class PacketChangerUpdate {
   private BlockPos pos;

   public PacketChangerUpdate() {
   }

   public PacketChangerUpdate(BlockPos pos) {
      this.pos = pos;
   }

   public static PacketChangerUpdate decode(PacketBuffer buf) {
      BlockPos pos = buf.func_179259_c();
      return new PacketChangerUpdate(pos);
   }

   public static void encode(PacketChangerUpdate packet, PacketBuffer buf) {
      buf.func_179255_a(packet.pos);
   }

   public static void handle(PacketChangerUpdate packet, Supplier<NetworkEvent.Context> ctx) {
      ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
         PlayerEntity player = ((NetworkEvent.Context)ctx.get()).getSender();
         World world = player.field_70170_p;
         TileEntity tile = world.func_175625_s(packet.pos);
         if (tile instanceof TileEntityBlockChanger) {
            TileEntityBlockChanger te = (TileEntityBlockChanger)tile;
            te.setNumbUse(0);
         }

         ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
      });
   }
}
